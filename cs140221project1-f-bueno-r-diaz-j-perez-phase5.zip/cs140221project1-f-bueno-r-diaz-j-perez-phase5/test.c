#include "types.h"
#include "user.h"
int main() {
	schedlog(10000);
	//printf(1, "first %d\n", priofork(2));
	//printf(1, "second %d\n", priofork(2));
	
	for (int i = 0; i < 5; i++) {
		if (i < 3 && fork() == 0) {
			char *argv[] = {"loop", 0};
			exec("loop", argv);
		}
		else if (i == 3 && priofork(1) == 0){ // i == 3 && priofork(1) == 0
			char *argv[] = {"loop", 0};
			exec("loop", argv);
		}
		else if (i == 4 && priofork(2) == 0){ // i == 4 && priofork(2) == 0
			//printf(1, "hello\n");
			char *argv[] = {"loop", 0};
			exec("loop", argv);
		}
	}
	
	for (int i = 0; i < 5; i++) {
		wait();
	}
	shutdown();
}